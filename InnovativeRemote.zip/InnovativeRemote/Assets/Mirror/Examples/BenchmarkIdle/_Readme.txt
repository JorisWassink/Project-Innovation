Benchmark with majority idle objects to test dirtyObjects technique.

This is generating large traffic.
The test requires Telepathy in order to not disconnect the client.