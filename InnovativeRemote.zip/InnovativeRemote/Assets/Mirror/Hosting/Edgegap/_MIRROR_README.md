Notes for Mirror integration:

-> Plugin needs to be zip drop in instead of package manager dependency:
   because Asset Store doesn't allow Github dependencies.

-> We have a few MIRROR CHANGES in the code for fixes / compatibility.